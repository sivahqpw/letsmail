<?php
   include('config.php');
   $GivenAdminName=$_POST['AdminName'];
   $GivenPassword=$_POST['Password'];
   
   
   if ($GivenAdminName!=$AdminName || $GivenPassword!=$AdminPassword){
                                                                      header('location:index.php?e=1');
                                                                      exit();
                                                                     }                       
                           
                        
   $LastLogin=date('m/d/Y');
   $ID=password_hash($AdminPassword, PASSWORD_BCRYPT, array("cost" => 10));
   setcookie('logconfirm',$ID,'0','/');
   header('location: members/index.php');
  exit();
                      
?>
