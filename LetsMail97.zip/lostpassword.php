 <br>
 <center>
  If you lost your password you will have to use FTP to manually <br>edit your config.php file.
  Please see the instructions if you need assistance doing this.
 </center>
 <br>&nbsp;<br>
 


