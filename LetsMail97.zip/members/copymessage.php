<?php
 include('../config.php');
 include('confirmuser.php');
 
 $M=(int)($_GET['e']);
 
 $re=mysqli_query($DbConn, "SELECT * FROM emails WHERE E_ID='$M' ")or die(mysqli_error($DbConn));
 if (mysqli_num_rows($re)<1){
                             echo "Some strange error happened!";
                             exit();
                            }
 $ro=mysqli_fetch_assoc($re);
 extract($ro);
 
 $re=mysqli_query($DbConn, "INSERT INTO emails (SendTo, Subject, Message, Schedule, DontSendTo, ScheduleDate, ScheduleTime, ExcludeList, UseTracking, SMTPAccount) VALUES('$SendTo', '$Subject', '$Message', '0', '$DontSendTo', '12/31/2050', '$ScheduleTime', '$ExcludeList', '$UseTracking', '$SMTPAccount' ) ") or die(mysqli_error($DbConn));                           
 
 
 header('location: index.php?p=e');
?>