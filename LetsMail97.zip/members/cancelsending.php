<?php
 include('../config.php');
 include('confirmuser.php');
 
 $M=(int)$_GET['M'];
 
 mysqli_query($DbConn, " DELETE FROM mailque WHERE Message='$M' ") or die(mysqli_error());

 
 header('location: index.php?p=messagestats&m='.$M);
 
 ?>