<?php
 include('../config.php');
 include('confirmuser.php');
 
 $M=(int)($_GET['m']);
 
 $re=mysqli_query($DbConn, " DELETE FROM emails WHERE E_ID='$M' ")or die(mysql_error());
 $re=mysqli_query($DbConn, " DELETE FROM opens WHERE Message='$M' ")or die(mysql_error());
 $re=mysqli_query($DbConn, " DELETE FROM clicks WHERE Message='$M' ")or die(mysql_error());
 $re=mysqli_query($DbConn, " DELETE FROM unsubs WHERE Message='$M' ")or die(mysql_error());
 $re=mysqli_query($DbConn, " DELETE FROM mailque WHERE Message='$M' ")or die(mysql_error());
 
 
 header('location: index.php?p=e');
?>