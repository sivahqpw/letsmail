<?php
 include('../config.php');
 include('confirmuser.php');
 
 $S=(int)$_GET['s'];
 
                                  
 $re=mysqli_query($DbConn, "DELETE FROM user_settings WHERE US_ID='$S'");
 
 header('location: index.php?p=se');
?>