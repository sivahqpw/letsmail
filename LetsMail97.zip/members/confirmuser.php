<?php
 $LogConfirm= $_COOKIE['logconfirm'];
 if ($LogConfirm == "") {
                         header('location: ../index.php');
                         exit();
                        }
 if (!password_verify ($AdminPassword,$LogConfirm)){
                       header('location: ../index.php');
                       exit();
                      }                       
                                                     
?>