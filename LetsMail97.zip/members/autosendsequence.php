<?php
 set_time_limit(240);
 ini_set('max_execution_time', 240);
 ignore_user_abort (true);
 
 include('../config.php');
 include('encript_functions.php');
 require 'PHPMailer-master/PHPMailerAutoload.php';
 include('getsiteurl.php');
 $SiteURL=str_replace("autosendsequence.php","",$SiteURL);
 
 
$MessageTable = "sequence_emails";
$QueTable = "sequence_que";
$ListTable = "lists";
$SubscribersTable = "subscribers"; 
 

 

 
echo "... checking for emails in sequence queue:<p>";
$re4=mysqli_query($DbConn," SELECT * FROM sequence_que LIMIT 10 ") or die(mysqli_error($DbConn));
while ($ro4=mysqli_fetch_assoc($re4)){ 
 extract($ro4);
 

//get the email contents
$re5=mysqli_query($DbConn, " SELECT SE_ID, Subject, Message, ForSequence, TotalSent, SMTPAccount FROM sequence_emails WHERE SE_ID='$SendMessage' ");
$ro5=mysqli_fetch_array($re5);
$SE_ID=$ro5['SE_ID'];                                     
$Subject=$ro5['Subject'];
$Message=$ro5['Message'];
$ForSequence=$ro5['ForSequence'];
$TotalSent=$ro5['TotalSent']; 
$SMTPAccount=$ro5['SMTPAccount']; 
 
 
 $re2s=mysqli_query($DbConn, "SELECT * FROM user_settings WHERE US_ID='$SMTPAccount'");
 $ro2s=mysqli_fetch_assoc($re2s);
 extract($ro2s);
 if ($SMTPHost=="" || $SMTPPassword=='' || $SMTPPort=='' ||  $Throttling=='' || $Confirmed!='1'){
                                                                               echo "--NOT SET UP--<br>";
                                                                               continue;
                                                                             }
 
                   
 date_default_timezone_set('Etc/UTC');

 $mail = new PHPMailer;
 //$mail->SMTPDebug  = 1;
 $mail->isSMTP();
 $mail->Host = $SMTPHost;
 $mail->SMTPAuth = true;      
 $mail->Timeout  =  10;
 if ($UseTLS==1){$mail->SMTPSecure = 'tls';}
 
 $mail->SMTPKeepAlive = true; // SMTP connection will not close after each email sent, reduces SMTP overhead
 $mail->Port = $SMTPPort;
 $mail->Username = $SMTPUserName;
 $mail->Password = simple_decrypt($SMTPPassword, $Key);
 $mail->Sender = $BounceEmail;
 $mail->setFrom($SMTPFrom, $SendName);
 $mail->ClearReplyTos();
 $mail->addReplyTo($SMTPReplyTo, $SendName);
 $mail->CharSet = 'UTF-8';
 $mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);
 $mail->Subject = stripslashes($Subject);
 $EmailMessage=stripslashes($Message);
 $EmailMessage = str_replace(array("www."), "", $EmailMessage); 
 
 $re=mysqli_query($DbConn, " SELECT ForList FROM sequences WHERE SQ_ID='$ForSequence' ");
 $ro=mysqli_fetch_array($re);
 $ListID=$ro['ForList'];
 echo "$ForSequence--$ListID--";
 //exit();
 
 $re=mysqli_query($DbConn, " SELECT HowJoined FROM $ListTable WHERE L_ID='$ListID' ");
 $ro=mysqli_fetch_assoc($re);
 extract($ro);
 
 

 $HowJoined="<br><font style='font-size:12px; color:#999999;'>".stripslashes($HowJoined)."</font><br>";
 $PhysicalAddress="<br><font style='font-size:12px; color:#999999;'>".stripslashes($PhysicalAddress)."</font><br>";
 
 
 
 
                               
                               $GLOBALS['SendTo']=$SendTo;
                               $GLOBALS['SE_ID']=$SE_ID;
                               $GLOBALS['SiteURL']=$SiteURL;
                                    echo "######<br>$Subject";
                                    $TrackingPixel="<img src='$SiteURL"."sequence_tracking.php?to=$SendTo&m=$SE_ID' alt='' style='display:none; visibility:hidden; width:1px; height:1px; overflow:hidden;'/>";
                                    $UnsubLink="<a href='$SiteURL"."unsubscribe.php?e=$SendTo&l=$ListID&m=s$SE_ID' style='font-size:12px;'>Click here to unsubscribe from these emails</a>";
                                   
                                   
                                   
                                   
                                  
                                   //change [name] tag to subscribers name
                                    $Results22 = mysqli_query($DbConn, " SELECT FirstName FROM $SubscribersTable WHERE EmailAddress='$SendTo' ");
                                    if (mysqli_num_rows($Results22)>0){
                                                                       $ro22=mysqli_fetch_assoc($Results22);
                                                                       extract($ro22);
                                                                       $FullName=$FirstName;
                                                                       $parts=explode(" ",$FullName);
                                                                       $FirstName=$parts['0'];
                                                                       $LastName=$parts['1'];
                                                                      };
                                    $EmailMessage2=str_ireplace("[name]",$FullName,$EmailMessage2);
                                    $EmailMessage2=str_ireplace("[first]",$FirstName,$EmailMessage2);
                                    $EmailMessage2=str_ireplace("[last]",$LastName,$EmailMessage2);
                                   
                                    
                                    
                                
                                    
                                    $mail->msgHTML("<div style='width:600px;'>".$EmailMessage.$TrackingPixel.$PhysicalAddress.$HowJoined.$UnsubLink.$EndMessage."</div>");
                                    $mail->AltBody = strip_tags($EmailMessage);
                                    $mail->addAddress($SendTo, $SendTo);  
                                    $SendResult=$mail->send(); //true / false        
                                    
                                    
                                    //debugging output///////////////////////////////////////////////////////////////////////////////////////////
                                    //echo "$SendTo<br>$EmailMessage2<br>";
                                    $DateXX=date('m/d/Y');
                                    if ($SendResult){
                                                     echo "--SENT--<br>&nbsp;<br><hr>";
                                                     $Message="Sequence was sent to: $SendTo for email $E_ID";
                                                     mysqli_query($DbConn,"INSERT INTO sending_logs (DateX, SendLog) VALUES('$U_ID', '$DateXX', '$Message' ) ");
                                                     }else{
                                                             if (strpos($SendResult, 'MAIL FROM command failed') !== false) {                                 
                                                                                                                              echo "--NOT SENT--<br>&nbsp;<br>".$mail->ErrorInfo."<p><hr>";
                                                                                                                              $Message="Sequence not sent to: $SendTo for email $E_ID error output:".$mail->ErrorInfo;
                                                                                                                              mysqli_query($DbConn, "INSERT INTO sending_errors (DateX, ErrorLog) VALUES('$DateXX', '$Message' ) ");
                                                                                                                            }else{
                                                                                                                                  $Message="Sequence was sent to: $SendTo for email $E_ID [with notice]";
                                                                                                                                  mysqli_query($DbConn,"INSERT INTO sending_logs (DateX, SendLog) VALUES('$U_ID', '$DateXX', '$Message' ) ");
                                                                                                                                 }  
                                                                                            }                            
                                    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                    
                                    $mail->clearAddresses();
                                  
                                    $re2=mysqli_query($DbConn," DELETE FROM $QueTable WHERE SQ_ID='$SQ_ID' ");
  
                                    $TotalSent=$TotalSent+1;                           
                                    $re3=mysqli_query($DbConn, " UPDATE $MessageTable SET TotalSent='$TotalSent' WHERE SE_ID='$SE_ID' ");

} 
                                   


                          
?>