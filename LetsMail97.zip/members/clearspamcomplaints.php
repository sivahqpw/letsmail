<?php
 include('../config.php');
 include('confirmuser.php');
 
 mysqli_query($DbConn, "DELETE FROM spam_complaints WHERE 1=1 ");
 header('location: index.php?p=spamc');
?>