<?php
 include('../config.php');
 $E=mysqli_real_escape_string($DbConn, $_GET['e']);
 $L=(int)$_GET['l'];
 mysqli_query($DbConn, " UPDATE subscribers SET Status='1' WHERE EmailAddress='$E' AND List='$L'");
?>
<h2>Your subscription has been confirmed</h2>
