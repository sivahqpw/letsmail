<?php
 $Table = "lists";
 $Results = mysqli_query( $DbConn, " SELECT * FROM $Table ");
 $LC=mysqli_num_rows($Results);
 if ($LC<1){
             echo "
                   <h3>You need to create a list first</h3>
                  ";
                                 
           }else{
?>
<h3>Add a single subscriber</h3>
<form method="post" action="doaddsubscriber.php">

 <table>
  <tr>
   <td>Select A List : </td><td>
                              <select name="List" style="width:350px;">
                               <?php
                                $re=mysqli_query( $DbConn, "SELECT * FROM $Table ");
                                while($ro=mysqli_fetch_assoc($re)){
                                                                   extract($ro);
                                                                   $ListName=stripslashes($ListName);
                                                                   echo "
                                                                         <option value='$L_ID'>$ListName</option>\n
                                                                        ";
                                                                  }
                               ?>
                              </select>
                            </td>
  </tr>
  <tr>
   <td>Name (optional) : </td><td><input type="text" style="width:300px" name="Name"></td>
  </tr>
  <tr>
   <td>Email Address : </td><td><input type="text" style="width:300px" name="EmailAddress"></td>
  </tr>
  <tr>
   <td colspan="2" height="70"><input type="submit" class="mb-2 mr-2 btn-transition btn btn-outline-primary" value=" Add Subscriber "></td>
  </tr>  
 </table>

</form>    


<?php
 }
?> 

