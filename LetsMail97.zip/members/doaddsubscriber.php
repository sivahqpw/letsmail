<?php

 include('../config.php');
 include('confirmuser.php');
 
 $Table = "subscribers";
 
 $List=trim(mysqli_real_escape_string($DbConn, $_POST['List']));
 $EmailAddress=trim(mysqli_real_escape_string($DbConn, $_POST['EmailAddress']));
 $Name=trim(mysqli_real_escape_string($DbConn, $_POST['Name']));
 $DateX=date('m/d/Y');
 
 $re=mysqli_query($DbConn, " SELECT * FROM $Table WHERE EmailAddress='$EmailAddress' AND List='$List' ");
 if (mysqli_num_rows($re)<1){
                            $re=mysqli_query($DbConn, "INSERT INTO $Table (FirstName, EmailAddress, List, Status, DateX) VALUES('$Name', '$EmailAddress', '$List', '1', '$DateX' ) ");  
                           }

                           
 header('location: index.php?p=su');

?>