<?php
 error_reporting(0);
 date_default_timezone_set('UTC');
 ini_set ( 'max_execution_time', 1200); 
  
 $MessageTable = "emails";
 $SubscribersTable = "subscribers";
 $QueTable = "mailque";
 $ListTable = "lists";
 $OpensTable = "opens";
 include('../config.php');

 $rem=mysqli_query($DbConn, " SELECT * FROM emails WHERE Schedule='0' ");
 while ($rom=mysqli_fetch_assoc($rem)){
 
 extract($rom);
 
 
 //get all opens for the 'dont send to' message
 unset($OpenedEmails);
 if ($DontSendTo!="0"){
                       $re=mysqli_query($DbConn, " SELECT Email FROM opens WHERE Message='$DontSendTo' ");
                       $c=0;
                       while ($ro=mysqli_fetch_assoc($re)){
                                                          extract($ro);
                                                          $OpenedEmails[$c]=$Email;
                                                          $c=$c+1;
                                                         }
                       //print_r($OpenedEmails);
                       //exit();
                      }    
                      
//get all emails for exclude list
unset($DontSendList);
if ($ExcludeList!="0"){
                       $re=mysqli_query($DbConn, " SELECT EmailAddress FROM subscribers WHERE List='$ExcludeList' ");
                       $c=0;
                       while ($ro=mysqli_fetch_assoc($re)){
                                                          extract($ro);
                                                          $DontSendList[$c]=$EmailAddress;
                                                          $c=$c+1;
                                                         }
                       //print_r($OpenedEmails);
                       //exit();
                      }                                                                  
 
 $TotalQued=0;
 $TotalExcluded=0;
                                      

 $TimeZoneOffset2=$TimeZoneOffset*3600;                           
 
                             
                                         
 $QueTime=strtotime($ScheduleDate);
 
 //360 seconds in an hour : -60 seconds to be sure it triggers in case the time() return is a bit later due to server lage
 $QueTime=$QueTime+($ScheduleTime*3600)-60;
 
 $CurTime=time()+$TimeZoneOffset2; 

 
 echo "Checking message $E_ID ($ForUser) -- <br>Que time is($ScheduleDate-/-$ScheduleTime) [$TimeZoneOffset2]----: $QueTime (".date('m/d/Y g:ia', $QueTime).") 
                                     Current time is:$CurTime (".date('m/d/Y g:ia', $CurTime).")<br>";

 if ($QueTime<$CurTime){
 echo "--Sending--<p>";
 $re=mysqli_query($DbConn, "UPDATE $MessageTable SET Schedule='1' WHERE E_ID='$E_ID' ");

 $DateX=date('m/d/Y');
 $re=mysqli_query($DbConn, "UPDATE $ListTable SET LastSent='$DateX' WHERE L_ID='$SendTo' ");
 
 
 $re=mysqli_query($DbConn, " SELECT * FROM $SubscribersTable WHERE List='$SendTo' AND Status='1' ") or  die(mysql_error());
 while ($ro=mysqli_fetch_assoc($re)){
                               extract($ro);
                                                     
                               //check if this is a email to an unopens segment and if it is check if this person opened
                               if ($DontSendTo!="0"){
                                                     //$Results = mysql_query( " SELECT  O_ID FROM $OpensTable WHERE Message='$DontSendTo' AND Email='$EmailAddress' ");
                                                     //$DidOpen=mysql_num_rows($Results);
                                                     $DidOpen=in_array($EmailAddress,$OpenedEmails);
                                                     //echo $DidOpen."<br>";
                                                    }else{
                                                          $DidOpen=0;
                                                         }     
                                                         
                               if ($ExcludeList!="0"){
                                                      $IsExcluded=in_array($EmailAddress,$DontSendList); 
                                                     }else{
                                                           $IsExcluded=0;
                                                          }                                                                                                                                            
                                                          
                               //echo "-$DidOpen-$DontSendTo-<br>";
                               if ($DidOpen!=1 && $IsExcluded!=1){

                                               $re2=mysqli_query($DbConn, "INSERT INTO $QueTable (SendTo, Message) VALUES('$EmailAddress', '$E_ID') ") or die(mysql_error());
                                               $tq=$tq+1;
                                               $re2=mysqli_query($DbConn, "UPDATE  emails SET TotalQued='$tq' WHERE E_ID='$E_ID' ");
                                               $TotalQued=$TotalQued+1;
                                               echo "qued: - $TotalQued<br>";
                                              }else{
                                                    $TotalExcluded=$TotalExcluded+1;
                                                    echo "excluded: - $TotalExcluded<br>";
                                                   } 
                               
                              }
                                   
                           

 }
}

?>