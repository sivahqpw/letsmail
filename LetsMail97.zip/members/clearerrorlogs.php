<?php
 include('../config.php');
 include('confirmuser.php');
 
 mysqli_query($DbConn, "DELETE FROM sending_errors WHERE 1=1 ");
 header('location: index.php?p=serror');
?>