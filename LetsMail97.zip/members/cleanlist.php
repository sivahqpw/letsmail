<?php
 include('../config.php');
 include('confirmuser.php');
 

 
 $l=(int)$_GET['l'];
 if ($l==0){
            header('location: index.php?p=lists');
            exit();
           }
           
                           
 $re=mysqli_query($DbConn," SELECT * FROM subscribers WHERE List='$l' ");
 while ($ro=mysqli_fetch_assoc($re)){
                                    extract($ro);
                                    //echo "Checking $EmailAddress ";
                                    $re2=mysqli_query($DbConn, " SELECT * FROM opens WHERE Email='$EmailAddress' ");
                                    $n=mysqli_num_rows($re2);
                                    //echo "$n opens .. ";
                                    if ($n<1){
                                              $re3=mysqli_query($DbConn, " DELETE FROM subscribers WHERE List='$l' AND EmailAddress='$EmailAddress' "); 
                                              $re3=mysqli_query($DbConn, " DELETE FROM unsubs WHERE List='$l' AND EmailAddress='$EmailAddress' ");
                                              //echo "DELETED";
                                   }else{ 
                                         //echo "NOT DELETED";
                                        }
                                  
                                   //echo "<br>";
                                  } 
 
  mysqli_query($DbConn, " DELETE FROM subscribers WHERE List='$l' AND Status!='1' "); 
  mysqli_query($DbConn, " DELETE FROM unsubs WHERE List='$l' AND Status!='1' ");
 
 header('location: index.php?p=l');
?>