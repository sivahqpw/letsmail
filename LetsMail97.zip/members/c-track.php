<?php
 include('../config.php');
 
 $link=mysqli_real_escape_string($DbConn, $_GET['link']);
 $RedirectURL=urldecode($link);
 $RedirectURL=str_replace('#','/', $RedirectURL);
 $M=$_GET['m'];
 $M=(int)$M;
 $DateX=date('m/d/Y');
 $Email=$_GET['email'];
 $Email=filter_var($Email, FILTER_SANITIZE_EMAIL);
 

 
 $re=mysqli_query($DbConn, "INSERT INTO clicks (Message, URL, DateX, Subscriber) VALUES('$M', '$RedirectURL', '$DateX', '$Email') ") or die(mysql_error());
 
 header("location: $RedirectURL");
?>