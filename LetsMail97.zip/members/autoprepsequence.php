<?php
 include('../config.php');
 date_default_timezone_set('UTC');
 ini_set ( 'max_execution_time', 1200); 
  
 //loop through all of the sequences emails
 $re=mysqli_query($DbConn, " SELECT * FROM sequence_emails WHERE SendDay!='0' ORDER BY ForSequence");
 
 while ($ro=mysqli_fetch_assoc($re)){
                                    extract($ro);
                                    echo "<b>Checking sequence email $SE_ID  for sequence $ForSequence - ";
                                    //get the list and SendDay for that sequence
                                    $re2=mysqli_query($DbConn, " SELECT ForList, RedirectList FROM sequences WHERE SQ_ID='$ForSequence' ");
                                    $ro2=mysqli_fetch_assoc($re2);
                                    extract($ro2);
                                    
                                   
            
                                    echo "sending to list $ForList</b><br>";
                                    
                                    //loop through all of the emails in the list for that sequence where the subscriber was not imported
                                    $re3=mysqli_query($DbConn, " SELECT EmailAddress, DateX FROM subscribers WHERE List='$ForList' AND Status='1' ")or die(mysql_error());
                                    while ($ro3=mysqli_fetch_assoc($re3)){
                                                                         extract($ro3);
                                                                         echo "Checking email address ###### added on $DateX";
                                                                         
                                                                         //check sequence record to make sure this subscriber did not get this sequence
                                                                         $re4=mysqli_query($DbConn, " SELECT * FROM sequence_record WHERE SentTo='$EmailAddress' AND SentMessage='$SE_ID' ");
                                                                         if (mysqli_num_rows($re4)<1){
                                                                                                     
                                                                                                     //check to make sure its the proper date to send the email, the number of days since  the subscriber was added should equal or greator than SendDay varable
                                                                                                     $start=strtotime($DateX);
                                                                                                     $end=time();
                                                                                                     $days_between=floor(abs($end - $start) / 86400);
                                                                                                     
                                                                                                     echo " - $days_between since subscriber was added, sequence email to be sent on $SendDay<p>";
                                                                                                     
                                                                                                     if ($days_between>=$SendDay){ 
                                                                                                                                  //add it to the que
                                                                                                                                  mysqli_query($DbConn, "INSERT INTO sequence_que (SendTo, SendMessage) VALUES('$EmailAddress', '$SE_ID') ");
                                                                                                                                  //add it to the perminant record
                                                                                                                                  mysqli_query($DbConn, "INSERT INTO sequence_record (SentTo, SentMessage) VALUES('$EmailAddress', '$SE_ID') ");
                                                                                                                                  //update sequence sent count
                                                                                                                                  //$TotalSent=$TotalSent+1;
                                                                                                                                  //mysql_query("UPDATE sequence_emails SET TotalSent='$TotalSent' WHERE SE_ID='$SE_ID' ");
                                                                                                                                  echo "--added to que --<br>Redirect List is $RedirectList";
                                                                                                                                 
                                                                                                                                 //if this is the last email in the sequence and there is a redirect list move the subscriber from the sequence list to the redirect list
                                                                                                                                 if ($RedirectList!=0){ 
                                                                                                                                                       $re7=mysqli_query($DbConn, " SELECT * FROM sequence_emails WHERE ForSequence='$ForSequence' AND SendDay>'$SendDay' ");
                                                                                                                                                       if (mysqli_num_rows($re7)<1){                                 
                                                                                                                                                                                    $re8=mysqli_query($DbConn, " SELECT * FROM subscribers WHERE List='$RedirectList' AND EmailAddress='$EmailAddress' ");
                                                                                                                                                                                    if (mysqli_num_rows($re8)<1){ 
                                                                                                                                                                                                                $re9=mysqli_query($DbConn, " UPDATE subscribers SET List='$RedirectList' WHERE EmailAddress='$EmailAddress' ");
                                                                                                                                                                                                                echo "**Subscriber list moved**";
                                                                                                                                                                                                               }else{
                                                                                                                                                                                                                     echo "**Subscriber already on redirect list**";
                                                                                                                                                                                                                    }
                                                                                                                                                                                  }
                                                                                                                                 
                                                                                                                                 echo "<p>";
                                                                                                                                 } 
                                                                                                    }
                                                                        }else{echo "<br>";}
                                    
                                   }
  }                                 
?>