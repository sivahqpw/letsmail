<?php
 include('../config.php');
 include('confirmuser.php');;
 
 $SE=(int)($_GET['se']);
 $S=(int)($_GET['s']);
 
 
 
 
 mysqli_query($DbConn, " DELETE FROM sequence_que WHERE SendMessage='$SE' ");
 mysqli_query($DbConn, " DELETE FROM sequence_record WHERE SentMessage='$SE' ");
 mysqli_query($DbConn, " DELETE FROM sequence_emails WHERE SE_ID='$SE' AND ForSequence='$S' ");
 
 
 header('location: index.php?p=sequenceemails&s='.$S);
?>