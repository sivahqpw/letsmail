<?php
 if (!file_exists('proupgrade.php')){$IsPro=false;}else{$IsPro=true;}
 set_time_limit(240);
 ini_set('max_execution_time', 240);
 ignore_user_abort (true); 
 
 include('../config.php');
 include('encript_functions.php');
 require 'PHPMailer-master/PHPMailerAutoload.php';
 include('getsiteurl.php');
 $SiteURL=str_replace("autosendmail.php","",$SiteURL);
  
 $MessageTable = "emails";
 $QueTable = "mailque";
 $ListTable = "lists";
 $SubscribersTable = "subscribers";
 
 $re1=mysqli_query($DbConn, " SELECT DISTINCT Message From mailque ");

 
 while ($ro1=mysqli_fetch_assoc($re1)){
 extract($ro1);
 $QueMessage=$Message;
  
//get the email contents
$re5=mysqli_query($DbConn, " SELECT E_ID, Subject, Message, SendTo, NumberSent, UseTracking, SMTPAccount FROM emails WHERE E_ID='$QueMessage' ");
$ro5=mysqli_fetch_array($re5);
$E_ID=$ro5['E_ID'];                                        
$Subject=$ro5['Subject'];
$Message=$ro5['Message'];
$ListID=$ro5['SendTo'];  
$NumberSent=$ro5['NumberSent']; 
$UseTracking=$ro5['UseTracking'];
$SMTPAccount=$ro5['SMTPAccount'];


//get the SMTP settings
$reS=mysqli_query($DbConn, " SELECT * FROM user_settings WHERE US_ID='$SMTPAccount' ") or die(mysqli_error($DbConn));
$roS=mysqli_fetch_assoc($reS);
extract($roS);

echo "Sending Message number .. $QueMessage ..From: $SMTPFrom / $SendName...$Throttling - List ID: $ListID<br>";
echo "Message text: $Message<hr>";

 
$PhysicalAddress="<br><font style='font-size:12px; color:#999999;'>".stripslashes($PhysicalAddress)."</font><br>";
 

 
 
 date_default_timezone_set('Etc/UTC');

 $mail = new PHPMailer;
 $mail->SMTPDebug  = 0;
 $mail->isSMTP();
 $mail->Host = $SMTPHost;
 $mail->SMTPAuth = true;      
 $mail->Timeout  =  10;
 if ($UseTLS==1){$mail->SMTPSecure = 'tls';}
 
 $mail->SMTPKeepAlive = true;
 $mail->Port = $SMTPPort;
 $mail->Username = $SMTPUserName;
 $mail->Password = simple_decrypt($SMTPPassword, $Key);
 $mail->Sender = $BounceEmail;
 $mail->setFrom($SMTPFrom, $SendName);
 $mail->ClearReplyTos();
 $mail->addReplyTo($SMTPReplyTo, $SendName);
 $mail->CharSet = 'UTF-8';
 $mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);

//print_r($mail);




 $mail->Subject = stripslashes($Subject);
 $EmailMessage=stripslashes($Message);
 $EmailMessage = str_replace(array("www."), "", $EmailMessage);
 
 
 $reH=mysqli_query($DbConn, " SELECT HowJoined FROM $ListTable WHERE L_ID='$ListID' ") or die(mysqli_error($DbConn));
 if (mysqli_num_rows($reH)>0){
                            $roH=mysqli_fetch_assoc($reH);
                            extract($roH);
                           } 
 $HowJoined="<br><font style='font-size:12px; color:#999999;'>".stripslashes($HowJoined)."</font><br>";


 
$re4=mysqli_query($DbConn, " SELECT SendTo, Q_ID FROM $QueTable WHERE Message='$QueMessage' LIMIT $Throttling ") or die(mysqli_error($DbConn));
while ($ro4=mysqli_fetch_assoc($re4)){ 
extract($ro4);

                               
                               $GLOBALS['SendTo']=$SendTo;
                               $GLOBALS['E_ID']=$E_ID;
                               $GLOBALS['SiteURL']=$SiteURL;
                                    //echo "$SendTo<br>$Subject";
                              
                               if ($UseTracking=="1"){ 
                                                      $TrackingPixel="<img src='$SiteURL"."tracking.php?to=$SendTo&m=$E_ID' alt='' style='display:none; visibility:hidden; width:1px; height:1px; overflow:hidden;'/>";
                                                     }
                               
                                                     
                               $UnsubLink="<a href='$SiteURL"."unsubscribe.php?e=$SendTo&l=$ListID&m=$E_ID' style='font-size:12px;'>Click here to unsubscribe from these emails</a>";
                                                 
                                    
                                    //adjust for click tracking, change links to redirect through sending domain / tracking URL
                               
                               if ($UseTracking=="1"){     
                                    $EmailMessage2 = preg_replace_callback('~<a\s+href="(.*?)"(.*?)>(.*?)</a>~i', function($m){
                                                                                                                              $SendTo=$GLOBALS['SendTo'];
                                                                                                                              $E_ID=$GLOBALS['E_ID'];
                                                                                                                              $SiteURL=$GLOBALS['SiteURL'];
                                                                                                                              $m[1]=str_replace('/','#',$m[1]);
                                                                                                                              return sprintf('<a href="'.$SiteURL.'c-track.php?m='.$E_ID.'&email='.$SendTo.'&link=%s"%s>%s</a>', urlencode($m[1]), $m[2], $m[3]);
                                                                                                                             }, $EmailMessage);
                                    
                                   
                                  }else{
                                        $EmailMessage2=$EmailMessage;
                                       }
                                       
                                      
                                  
                                    
                                    //change [name] tag to subscribers name
                                    $Results22 = mysqli_query($DbConn, " SELECT FirstName FROM $SubscribersTable WHERE EmailAddress='$SendTo' ");
                                    if (mysqli_num_rows($Results22)>0){
                                                                       $ro22=mysqli_fetch_assoc($Results22);
                                                                       extract($ro22);
                                                                       $FullName=$FirstName;
                                                                       $parts=explode(" ",$FullName);
                                                                       $FirstName=$parts['0'];
                                                                       $LastName=$parts['1'];
                                                                      };
                                    $EmailMessage2=str_ireplace("[name]",$FullName,$EmailMessage2);
                                    $EmailMessage2=str_ireplace("[first]",$FirstName,$EmailMessage2);
                                    $EmailMessage2=str_ireplace("[last]",$LastName,$EmailMessage2);
                                                             
                                                                 
                                                             
                                    
                                    if (!$IsPro){
                                                     $EndMessage="<br>&nbsp;<br><font style='font-size:16px;'>Powered by the LetsMail email software (unlimited emails, no monthly fee)</font>";
                                                    }else{
                                                          $EndMessage="";
                                                         }
                                
                             
                                    $EndMessage2="<br>&nbsp;<br><a href='$SiteURL"."hardspamreport.php?u=$U_ID&e=$SendTo&l=$ListID' style='font-size:12px; color:#990000'>Is this spam? Click here to report!</a>";
                             
                                    $mail->msgHTML("<div style='width:600px;'>".$EmailMessage2.$TrackingPixel.$PhysicalAddress.$HowJoined.$UnsubLink.$EndMessage.$EndMessage2."</div>");
                                    $mail->AltBody = strip_tags($EmailMessage);
                                    $mail->addAddress($SendTo, $SendTo); 
                                    $SendResult=$mail->send();
                                   
                                    
      
                                    
                                    //debugging output///////////////////////////////////////////////////////////////////////////////////////////
                                    //echo "$SendTo<br>$EmailMessage2<br>";
                                    $DateXX=date('m/d/Y');
                                    if ($SendResult){
                                                     echo "--SENT--<br>&nbsp;<br><hr>";
                                                     $Message="Broadcast was sent to: $SendTo for email $E_ID";
                                                     mysqli_query($DbConn, "INSERT INTO sending_logs (DateX, SendLog) VALUES('$DateXX', '$Message' ) ");
                                                     }else{
                                                                                             
                                                            if (strpos($SendResult, 'MAIL FROM command failed') !== false) {                                 
                                                                                             
                                                                                                                             echo "--NOT SENT--<br>&nbsp;<br>".$mail->ErrorInfo."<p>";
                                                                                                                             echo "<hr>";
                                                                                                                             $M="Broadcast not sent to: $SendTo for email $E_ID error output:".$mail->ErrorInfo;
                                                                                                                             mysqli_query($DbConn, "INSERT INTO sending_errors (DateX, ErrorLog) VALUES('$DateXX', '$M' ) ");
                                                                                                                            }else{
                                                                                                                                  $Message="Broadcast was sent to: $SendTo for email $E_ID - [with notice]";
                                                                                                                                  mysqli_query($DbConn, "INSERT INTO sending_logs (DateX, SendLog) VALUES('$DateXX', '$Message' ) ");
                                                                                                                                  echo "--SENT WITH NOTICE $SendTo--<br>".$mail->ErrorInfo."<br><hr>";
                                                                                                                                 }
                                                                                             
                                                                                                                 
                                                                                            } 
                                                                                            
                                   //echo "***************************<br>$SendTo<br>$SendResult***************************<br>";                                                      
                                                                                                                                
                                    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                    
                                    $mail->clearAddresses();
                                  
                                    $re2=mysqli_query($DbConn, " DELETE FROM $QueTable WHERE Q_ID='$Q_ID' ");
  
                                    $NumberSent=$NumberSent+1;                        
                                    $re3=mysqli_query($DbConn," UPDATE $MessageTable SET NumberSent='$NumberSent' WHERE E_ID='$E_ID' ");

                                   } 
                                  
                        $mail->smtpClose();            
                        } 
                                   

                               
                                 
mysqli_close($DbConn);
?>


