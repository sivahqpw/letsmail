<?php
 include('../config.php');
 include('confirmuser.php');
 $D=$_POST['D'];
 $D=mysqli_real_escape_string($DbConn, $D);
 
 $re=mysqli_query($DbConn, "SELECT * FROM spam_complaints WHERE DateX='$D' ");
 $ComplaintCount=mysqli_num_rows($re);

?>
<center>
 <h4>Total spam complaints for date <?php echo $D; ?>: <?php echo $ComplaintCount; ?></h4>
</center>