<?php
error_reporting(0);
    
    include('../config.php');
    include('confirmuser.php');
    include('encript_functions.php');
    
    $SubscribersTable="subscribers";
    $TotalBounces=0;
    $re=mysqli_query($DbConn, " SELECT * FROM user_settings ");
    while ($ro=mysqli_fetch_assoc($re)){
    extract($ro);
    
    $BouncePassword=simple_decrypt($BouncePassword, $Key);
    
    $mailbox = "{".$IMAPHost.":".$IMAPPort."/notls}INBOX";
    //$mailbox = "{".$IMAPHost.":".$IMAPPort."/imap/ssl/novalidate-cert/norsh}Inbox";
    //echo $mailbox."<br>";
    
    $imap = imap_open($mailbox,$BounceUser,$BouncePassword) or die(imap_last_error());
    //$imap = imap_open($mailbox,$BounceUser,$BouncePassword);
    //echo imap_last_error();
    //exit();

    
 
    $headers = imap_headers($imap);

    $MessageCount=0;
    if (!$headers) {
                    //do nothing no emails
                    } else {
                            foreach($headers as $header) {
                                                          $MessageCount=$MessageCount+1;
                                                          imap_delete($imap, $MessageCount);
                                                          //print "$header<br>";
                                                          $Mail_Data = (array)imap_headerinfo($imap, $MessageCount);
                                                          //echo "<h2>($MessageCount)".$Mail_Data['Subject']."</h2>";
                                                          //print_r($Mail_Data);
                                                          $MailBody = trim(substr(imap_body($imap, $MessageCount), 0, 100000));
                                                          //echo $MailBody;
                                                          //search for emails:
                                                          
                                                          
                                                          $pattern = '/[a-z0-9_\-\+]+@[a-z0-9\-]+\.([a-z]{2,3})(?:\.[a-z]{2})?/i';
                                                          preg_match_all($pattern, $MailBody, $matches);
                                                          $Matches=$matches[0];
                                                          $Matches=array_unique($Matches);
                                                          $Matches=array_values($Matches);
                                                          //print_r($Matches);
                                                          
                                                          
                                                          
                                                          //check for a spam complaint
                                                          $MarkedAsSpam=false;
                                                          if (strpos($MailBody, 'spam') !== false) {$MarkedAsSpam=true;}
                                                          if (strpos($MailBody, 'complaint') !== false) {$MarkedAsSpam=true;}
                                                          
                                                          //check for a hard bounce
                                                          $IsPermanent=false;
                                                          if (strpos($MailBody, 'permanent') !== false) {$IsPermanent=true;}
                                                          if (strpos($MailBody, 'rejected') !== false) {$IsPermanent=true;}
                                                          if (strpos($MailBody, 'refused') !== false) {$IsPermanent=true;}
                                                          if (strpos($MailBody, 'not accepted') !== false) {$IsPermanent=true;}
                                                          
                                                          //echo "<h2>$MarkedAsSpam - $IsPermanent</h2>";
                                                          
                                                          //check if any emails are in the database and if so flag them.
                                                          $c=0;
                                                          while ($c<count($Matches)){
                                                                                      $E=$Matches[$c];
                                                                                      
                                                                                      //make sure this is not the bounce or sending email, if it is not check if its a subscriber
                                                                                       if ($E!=$BounceEmail && $E!=$SMTPFrom){
                                                                                                                              //echo "*$E*<br>";
                                                                                                                              //$sql=" SELECT * FROM $SubscribersTable WHERE EmailAddress='$E' ";
                                                                                                                              //$re=$wpdb->query($sql);
                                                                                                                              $Results2 = mysqli_query( $DbConn, " SELECT * FROM $SubscribersTable WHERE EmailAddress LIKE '%$E%' ");
                                                                                                                              
                                                                                                                              while($ro2=mysqli_fetch_assoc($Results2)){
                                                                                                                               
                                                                                                                                                              extract($ro2);
                                                                                                                                                              //echo "--$EmailAddress - $BounceCount -$IsPermanent-$MarkedAsSpam --<br>";
                                                                                                                                                              $BounceCount=$BounceCount+1;
                                                                                                                                                              if ($Status=="1"){
                                                                                                                                                                                $TotalBounces=$TotalBounces+1;
                                                                                                                                                                               }
                                                                                                                                                              
                                                                                                                                                              //the line below incriments all bounces
                                                                                                                                                              //$wpdb->update( $SubscribersTable, array('BounceCount' => $BounceCount),array( 'S_ID' => $S_ID ));
                                                                                                                                                              mysqli_query($DbConn, " UPDATE $SubscribersTable SET BounceCount='$BounceCount' WHERE S_ID='$S_ID' ");
                                                                                                                                                              
                                                                                                                                                              
                                                                                                                                                              if ($IsPermanent || $BounceCount>$BounceTolerance){
                                                                                                                                                                                                                 //$wpdb->update( $SubscribersTable, array('Status' => '2'),array( 'S_ID' => $S_ID )); 
                                                                                                                                                                                                                 mysqli_query($DbConn, " UPDATE $SubscribersTable SET Status='2' WHERE S_ID='$S_ID' ");
                                                                                                                                                                                                                }   
                                                                                                                                                                                                                
                                                                                                                                                              if ($MarkedAsSpam){
                                                                                                                                                                                 //$wpdb->update( $SubscribersTable, array('Status' => '3'),array( 'S_ID' => $S_ID )); 
                                                                                                                                                                                 mysqli_query($DbConn, " UPDATE $SubscribersTable SET Status='3' WHERE S_ID='$S_ID' ");
                                                                                                                                                                                }                                                                 
                                                                                                                                                                                
                                                                                                                                                           }
                                                                                                                              
                                                                                                                             } 
                                                                                      
                                                                                      $c=$c+1;
                                                                                     }
                                                          
                                                          
                                                          //echo "<hr>";
                                                          unset($Matches);
                                                          unset($matches);
                                                         
                                                         }
                    }
    
    ;
  
   
  
    imap_expunge($imap);
    imap_close($imap);
 }
 echo "$TotalBounces";   
?>
