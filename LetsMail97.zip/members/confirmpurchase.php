<?php
 include('../config.php');
 include('confirmuser.php');
 $ReceiptID=$_POST['ReceiptID'];
 
 $IsValid=false;
 
 $Parts=explode('-', $ReceiptID);
 if ($Parts['0']=='AP'){$IsValid=true;}
 
 $Parts2=explode('_', $ReceiptID);
 if ($Parts2['0']=='ch'){$IsValid=true;}
 
 if ($IsValid){
               $f=fopen('proupgrade.php','w');
               fwrite($f,$ReceiptID);
               fclose($f);
               echo "<h3>Your upgrade has been proccessed.</h3>";
               echo "<a href='index.php'>Click here to continue.</a>";
              }else{
                    echo "<h3>Your receipt ID does not seem to be valid.</h3>";
                    echo "<a href='index.php'>Click here to continue.</a>";
                   }
?>