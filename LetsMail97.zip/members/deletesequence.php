<?php
 include('../config.php');
 include('confirmuser.php');
 
 $S=(int)$_GET['s'];
 
 
 $re=mysqli_query($DbConn, "DELETE FROM sequences WHERE SQ_ID='$S' ");
 
 //delete all the qued emails and records for this sequence
 $re=mysqli_query($DbConn," SELECT * FROM sequence_emails WHERE ForSequence='$S' ");
 while ($ro=mysqli_fetch_assoc($re)){
                                    extract($ro);
                                    mysqli_query($DbConn, " DELETE FROM sequence_que WHERE SendMessage='$SE_ID' ");
                                    mysqli_query($DbConn, " DELETE FROM sequence_record WHERE SentMessage='$SE_ID' ");
                                   }
 
 $re=mysqli_query($DbConn, "DELETE FROM sequence_emails WHERE ForSequence='$S' ");
 
 
 header('location: index.php?p=s');
?>