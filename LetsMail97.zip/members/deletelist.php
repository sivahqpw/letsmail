<?php
 include('../config.php');
 include('confirmuser.php');
 
 $L=(int)$_GET['l'];
 

 
 
 $re=mysqli_query($DbConn, "DELETE FROM lists WHERE L_ID='$L'"); 
 $re=mysqli_query($DbConn, "DELETE FROM subscribers WHERE List='$L'");
 $re=mysqli_query($DbConn, "DELETE FROM emails WHERE SendTo='$L'");
 $re=mysqli_query($DbConn, "DELETE FROM mailque WHERE SendTo='$L'");
 $re=mysqli_query($DbConn, "DELETE FROM unsubs WHERE List='$L'");

 
 //loop through all sequences, deletes lists and emails for that sequence
 $re=mysqli_query($DbConn, " SELECT  SQ_ID FROM sequences WHERE ForList='$L' ");
 while ($ro=mysqli_fetch_assoc($re)){
                                   extract($ro);
                                   $re2=mysqli_query($DbConn, " SELECT SE_ID from sequence_emails WHERE ForSequence='$SQ_ID' ");
                                   while ($ro2=mysqli_fetch_assoc($re2)){
                                                                        extract($ro2);
                                                                        mysqli_query($DbConn, " DELETE FROM sequence_record WHERE SentMessage='$SE_ID' ");
                                                                       }
                                  
                                  mysqli_query($DbConn, " DELETE FROM sequence_emails WHERE ForSequence='$SQ_ID' ");
                                  }
 $re=mysqli_query($DbConn, "DELETE FROM sequences WHERE ForList='$L'");
 
 header('location: index.php?p=l');
?>