<?php
 include('../config.php');
 include('confirmuser.php');
 
 $S=(int)$_GET['s'];
 $SL=(int)$_GET['sl'];
 

 

 $re=mysqli_query($DbConn, "DELETE FROM subscribers WHERE S_ID='$S' AND List='$SL' ");
 
 
 header('location: index.php?p=su&sl='.$SL);
?>